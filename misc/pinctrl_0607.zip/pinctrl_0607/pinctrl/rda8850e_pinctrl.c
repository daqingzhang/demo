#include <common.h>
#include <dm/device.h>
#include <dm/pinctrl.h>
#include <errno.h>
#include <asm/io.h>
#include <asm/arch/hwcfg.h>
#include <asm/arch/rda_iomap.h>
#include <asm/arch/reg_gpio.h>
#include <asm/arch/reg_cfg_regs.h>
#include <asm/arch/rda_pinctrl.h>

#define RDA_PINCTRL_DEBUG

#if defined(RDA_PINCTRL_DEBUG)
#define dprintf	printf
#else
#define dprintf(...) do{}while(0)
#endif

/*
 * private pinctrl data definition
 *****************************************************************************
 */

struct rda_fdt_node rda_pinctrl_fdt_node_ids[] = {

	{RDA_PINCTRL_ID_UART1,	"uart1"},
	{RDA_PINCTRL_ID_UART2,	"uart2"},
	{RDA_PINCTRL_ID_UART3,	"uart3"},
	{RDA_PINCTRL_ID_IODRIVE,"iodrive"},
	{RDA_PINCTRL_ID_BOOTMODE,"bootmode"},
	{RDA_PINCTRL_ID_GPIOA,	"gpioa"},
	{RDA_PINCTRL_ID_GPIOB,	"gpiob"},
	{RDA_PINCTRL_ID_GPIOC,	"gpioc"},
	{RDA_PINCTRL_ID_GPIOD,	"gpiod"},
	{RDA_PINCTRL_ID_GPOA,	"gpoa"},
	{RDA_PINCTRL_ID_CLK32K, "clk32k"},
	{RDA_PINCTRL_ID_USBID,  "usbid"},
	{RDA_PINCTRL_ID_KEYIN,  "keyin"},
	{RDA_PINCTRL_ID_KEYOUT, "keyout"},
	{RDA_PINCTRL_ID_I2C1,   "i2c1"},
	{RDA_PINCTRL_ID_I2C2,   "i2c2"},
	{RDA_PINCTRL_ID_I2C3,   "i2c3"},
};

static int rda_pinctrl_periph_id[] = {

	RDA_PINCTRL_ID_IODRIVE,
	RDA_PINCTRL_ID_BOOTMODE,
	RDA_PINCTRL_ID_CLK32K,
	RDA_PINCTRL_ID_USBID,
	RDA_PINCTRL_ID_GPIOA,
	RDA_PINCTRL_ID_GPIOB,
	RDA_PINCTRL_ID_GPIOC,
	RDA_PINCTRL_ID_GPIOD,
	RDA_PINCTRL_ID_GPOA,
	RDA_PINCTRL_ID_KEYIN,
	RDA_PINCTRL_ID_KEYOUT,
};

struct rda_pin_gpio platdata_bm[] = {
	RDA_PIN_GPIO_INIT("gpioa",0),
	RDA_PIN_GPIO_INIT("gpiob",0),
	RDA_PIN_GPIO_INIT("gpioc",0),
	RDA_PIN_GPIO_INIT("gpiod",0),
};

struct rda_pin_gpio platdata_gpio[] = {
	RDA_PIN_GPIO_INIT("gpioa",0),
	RDA_PIN_GPIO_INIT("gpiob",0),
	RDA_PIN_GPIO_INIT("gpioc",0),
	RDA_PIN_GPIO_INIT("gpiod",0),
	RDA_PIN_GPIO_INIT("gpoa",0),
};

static rda_pin_iodrive_t platdata_iodrive = {
	.reg1 = 0,
	.reg2 = 0,
};

struct rda_pin_common platdata_clk32k_usbid[] = {
	[0] = {
		.name = "clk32k",
		.nr = 1,
		.pin = RDA_PIN_INIT("pin",0,0,0,0),
	},
	[1] = {
		.name = "usbid",
		.nr = 1,
		.pin = RDA_PIN_INIT("pin",0,0,0,0),
	},
};

struct rda_pin_keyin platdata_keyin = {
	.name = "keyin",
	.nr = 8,
	.in[0] = RDA_PIN_INIT("in0",0,0,0,0,),
	.in[1] = RDA_PIN_INIT("in1",0,0,0,0,),
	.in[2] = RDA_PIN_INIT("in2",0,0,0,0,),
	.in[3] = RDA_PIN_INIT("in3",0,0,0,0,),
	.in[4] = RDA_PIN_INIT("in4",0,0,0,0,),
	.in[5] = RDA_PIN_INIT("in5",0,0,0,0,),
	.in[6] = RDA_PIN_INIT("in6",0,0,0,0,),
	.in[7] = RDA_PIN_INIT("in7",0,0,0,0,),
};

struct rda_pin_keyout platdata_keyin = {
	.name = "keyin",
	.nr = 8,
	.out[0] = RDA_PIN_INIT("out0",0,0,0,0,),
	.out[1] = RDA_PIN_INIT("out1",0,0,0,0,),
	.out[2] = RDA_PIN_INIT("out2",0,0,0,0,),
	.out[3] = RDA_PIN_INIT("out3",0,0,0,0,),
	.out[4] = RDA_PIN_INIT("out4",0,0,0,0,),
	.out[5] = RDA_PIN_INIT("out5",0,0,0,0,),
	.out[6] = RDA_PIN_INIT("out6",0,0,0,0,),
	.out[7] = RDA_PIN_INIT("out7",0,0,0,0,),
};

struct rda_pin_uart platdata_uart[] = {
	[0] = {
		.name = "uart1",
		.nr = 4,
		.rxd = RDA_PIN_INIT("rxd",0,0,0,0),
		.txd = RDA_PIN_INIT("txd",0,0,0,0),
		.cts = RDA_PIN_INIT("cts",0,0,0,0),
		.rts = RDA_PIN_INIT("rts",0,0,0,0),
	},
	[1] = {
		.name = "uart2",
		.nr = 4,
		.rxd = RDA_PIN_INIT("rxd",0,0,0,0),
		.txd = RDA_PIN_INIT("txd",0,0,0,0),
		.cts = RDA_PIN_INIT("cts",0,0,0,0),
		.rts = RDA_PIN_INIT("rts",0,0,0,0),
	},
	[2] = {
		.name = "uart3",
		.nr = 4,
		.rxd = RDA_PIN_INIT("rxd",0,0,0,0),
		.txd = RDA_PIN_INIT("txd",0,0,0,0),
		.cts = RDA_PIN_INIT("cts",0,0,0,0),
		.rts = RDA_PIN_INIT("rts",0,0,0,0),
	},
};

struct rda_pin_i2c platdata_i2c[] = {
	[0] = {
		.name = "i2c1",
		.nr = 2,
		.scl = RDA_PIN_INIT("scl",0,0,0,0),
		.sda = RDA_PIN_INIT("sda",0,0,0,0),
	},
	[1] = {
		.name = "i2c2",
		.nr = 2,
		.scl = RDA_PIN_INIT("scl",0,0,0,0),
		.sda = RDA_PIN_INIT("sda",0,0,0,0),
	},
	[2] = {
		.name = "i2c3",
		.nr = 2,
		.scl = RDA_PIN_INIT("scl",0,0,0,0),
		.sda = RDA_PIN_INIT("sda",0,0,0,0),
	},
};

static struct rda_pinctrl_platdata rda_platdata[] = {
	[0] = {
		.name 		= "rda-platdata",
		.id 		= 0,
		.valid 		= 0,
		.node_index 	= 0,
		.pinctrl_offset = 0,
		.boot_mode 	= 0,
		.altmux		= 0,
		.bm		= platdata_bm,
		.gpio 		= platdata_gpio,
		.iodrive	= &platdata_iodrive,
		.clk32k		= &platdata_clk32k_usbid[0],
		.usbid		= &platdata_clk32k_usbid[1],
		.uart		= platdata_uart,
		.keyin		= platdata_keyin,
		.keyout		= platdata_keyout,
		.i2c		= platdata_i2c,
	},
};

static struct rda_pin_bank rda_bank_group[] = {
	/* GPIO_A */
	RDA_PIN_BANK_INIT(0,"gpioa",32,RDA_GPIO_A_BASE,RDA_CFG_REGS_BASE),
	/* GPIO_B */
	RDA_PIN_BANK_INIT(1,"gpiob",32,RDA_GPIO_B_BASE,RDA_CFG_REGS_BASE),
	/* GPIO_C */
	RDA_PIN_BANK_INIT(2,"gpioc",32,RDA_GPIO_BASE,RDA_CFG_REGS_BASE),
	/* GPIO_D */
	RDA_PIN_BANK_INIT(3,"gpiod",32,RDA_GPIO_D_BASE,RDA_CFG_REGS_BASE),
	/* GPOA */
	RDA_PIN_BANK_INIT(4,"gpoa" ,10,RDA_GPIO_A_BASE,RDA_CFG_REGS_BASE),
};

/*
 * private pinctrl function definition
 *****************************************************************************
 */

static inline u32 pinctrl_platdata_valid(struct rda_pinctrl_platdata *platdata)
{
//	return platdata->valid;
	return 1;
}

static int pinctrl_get_io_drive(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	int node = platdata->pinctrl_offset,offset;
	void *blob = platdata->blob;
	rda_pin_iodrive_t *iodrive = platdata->iodrive;
	u32 prop = 0;

	if((node < 0) || (blob <= 0) || (!iodrive))
		return -EINVAL;
	if(platdata->periph >= ARRAY_SIZE(rda_pinctrl_fdt_node_ids))
		return -ENODATA;

	offset = fdt_subnode_offset(blob,node,
				rda_pinctrl_fdt_node_ids[platdata->periph].name);
	if(offset < 0)
		return -EFAULT;

	fdtdec_get_int_array(blob,offset,"ddr",&prop,1);
	iodrive->ddr = prop;

	fdtdec_get_int_array(blob,offset,"psram1",&prop,1);
	iodrive->psram1 = prop;

	fdtdec_get_int_array(blob,offset,"psram2",&prop,1);
	iodrive->psram2 = prop;

	fdtdec_get_int_array(blob,offset,"nflash",&prop,1);
	iodrive->nflash = prop;

	fdtdec_get_int_array(blob,offset,"lcd1",&prop,1);
	iodrive->lcd1 = prop;

	fdtdec_get_int_array(blob,offset,"lcd2",&prop,1);
	iodrive->lcd2 = prop;

	fdtdec_get_int_array(blob,offset,"sdat1",&prop,1);
	iodrive->sdat1 = prop;

	fdtdec_get_int_array(blob,offset,"sdat2",&prop,1);
	iodrive->sdat2 = prop;

	fdtdec_get_int_array(blob,offset,"camera",&prop,1);
	iodrive->camera = prop;

	fdtdec_get_int_array(blob,offset,"sim1",&prop,1);
	iodrive->sim1 = prop;

	fdtdec_get_int_array(blob,offset,"sim2",&prop,1);
	iodrive->sim2 = prop;

	fdtdec_get_int_array(blob,offset,"sim3",&prop,1);
	iodrive->sim3 = prop;

	fdtdec_get_int_array(blob,offset,"gpio",&prop,1);
	iodrive->gpio = prop;

	dprintf("%s, iodrive->reg1 = %8x\n",__func__,iodrive->reg1);
	dprintf("%s, iodrive->reg1 = %8x\n",__func__,iodrive->reg2);
	return 0;
}

static int pinctrl_set_io_drive(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	rda_pin_iodrive_t *iodrive = platdata->iodrive;
	u32 reg_base = bank_grp[0].reg_base_cfg;
	u32 iodrive1 = reg_base + 0x1C;
	u32 iodrive2 = reg_base + 0x20;

	if((!iodrive) || (!reg_base))
		return -EINVAL;
	/*
	 * TODO: before write register, need to check
	 * iodrive bit field for avoiding data overflow
	 */
	writel(iodrive->reg1,iodrive1);//iodrive1 register
	writel(iodrive->reg2,iodrive2);//iodrive2 register

	dprintf("%s, iodrive1 %8x = %8x\n",__func__,iodrive1,readl(iodrive1));
	dprintf("%s, iodrive2 %8x = %8x\n",__func__,iodrive2,readl(iodrive2));
	return 0;
}

static int pinctrl_iodrive_config(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	int r;
	r = pinctrl_get_io_drive(bank_grp,platdata);
	if(r) {
		printf("%s, get io drive failed, %d\n",__func__,r);
		return r;
	}
	r = pinctrl_set_io_drive(bank_grp,platdata);
	if(r) {
		printf("%s, set io drive failed, %d\n",__func__,r);
		return r;
	}
	return 0;
}

static int pinctrl_get_bm(struct rda_pin_bank *bank_grp,
				struct rda_pinctrl_platdata *platdata)
{
	int node = platdata->pinctrl_offset,offset;
	u32 buf[32],nr,i,j;
	void *blob = platdata->blob;
	struct rda_pin_gpio *ptr_bm = platdata->bm;

	if((node < 0) || (blob <= 0) || (!ptr_bm))
		return -EINVAL;

	for(i = 0; i < ARRAY_SIZE(platdata_bm);i++)
		ptr_bm[i].pin_nr = 0;

	offset = fdt_subnode_offset(blob,node,
			rda_pinctrl_fdt_node_ids[platdata->periph].name);
	if(offset < 0)
		return -EFAULT;

	node = offset;
	for(i = 0;i < ARRAY_SIZE(platdata_bm);i++) {
		nr = 0;
		offset = fdt_subnode_offset(blob,node,ptr_bm[i].name);
		fdtdec_get_int_array(blob,offset,"nr",&nr,1);
		ptr_bm[i].pin_nr = nr;
		if(nr > 0) {
			fdtdec_get_int_array(blob,offset,"pins",buf,nr);
			for(j = 0;j < nr;j++)
				ptr_bm[i].pin_id[j] = (u8)(buf[j]);
			fdtdec_get_int_array(blob,offset,"direct",buf,nr);
			for(j = 0;j < nr;j++)
				ptr_bm[i].pin_direct[j] = (u8)(buf[j]);
		}
#ifdef RDA_PINCTRL_DEBUG
		for(j = 0;j < ptr_bm[i].pin_nr;j++)
			printf("%s, %s, nr = %d, id = %d, direct = %d\n",__func__,
				ptr_bm[i].name,
				ptr_bm[i].pin_nr,
				ptr_bm[i].pin_id[j],
				ptr_bm[i].pin_direct[j]);
#endif
	}
	return 0;
}

static u32 pinctrl_get_gpio_pin_direction(struct rda_pin_gpio *gpio)
{
	u32 val = 0,mask,i;
	if(!gpio)
		return 0;
	for(i = 0;i < gpio->pin_nr;i++) {
		mask	= gpio->pin_direct[i];
		val	= val | (mask << i);
	}
	dprintf("%s,direct = %x\n",__func__,val);
	return val;
}

static int pinctrl_get_bm_pin_direction(struct rda_pin_gpio *gpio)
{
	u32 val = 0,shift,i;
	if(!gpio)
		return 0;
	for(i = 0;i < gpio->pin_nr;i++) {
		shift	= gpio->pin_id[i];
		val	= val | (1 << shift);
	}
	dprintf("%s, direct = %x\n",__func__,val);
	return val;
}

int pinctrl_set_bm(struct rda_pin_bank *bank_grp,
				struct rda_pinctrl_platdata *platdata)
{
	u32 gpio_clr,gpio_oen_set_out;
	u32 gpio_data[4],bm_data[4],t;
	int i = 0,num;

	if((!bank_grp) || (!platdata))
		return -EINVAL;

	num = ARRAY_SIZE(platdata_bm);
	if(num > ARRAY_SIZE(rda_bank_group))
		return -ENODATA;

	for(i = 0;i < num;i++) {
		bm_data[i] = pinctrl_get_bm_pin_direction(&platdata->bm[i]);
		gpio_data[i] = pinctrl_get_gpio_pin_direction(&platdata->gpio[i]);
	}

	for(i = 0;i < num;i++) {
		gpio_clr = bank_grp[i].reg_base_gpio + 0x14;
		gpio_oen_set_out = bank_grp[i].reg_base_gpio + 0x04;
		t =  gpio_data[i] & (~(bm_data[i]));

		writel(t,gpio_clr);
		writel(t,gpio_oen_set_out);

		dprintf("%s, gpio_data[%d] = %x, bm_data[%d] = %d\n",
			__func__,i,gpio_data[i],i,bm_data[i]);
	}
	return 0;
}

static int pinctrl_bm_config(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	int r;
	r = pinctrl_get_bm(bank_grp,platdata);
	if(r) {
		dprintf("%s, get bm failed, %d\n",__func__,r);
		return r;
	}
#if 0
	r = pinctrl_set_bm(bank_grp,platdata);
	if(r) {
		dprintf("%s, set bm failed, %d\n",__func__,r);
		return r;
	}
#endif
	return 0;
}

static int pinctrl_get_gpio(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	void *blob;
	int node,offset,err,id;
	u32 buf[32],nr,i;
	struct rda_pin_gpio *ptr_data;
	const char *name;

	name	= rda_pinctrl_fdt_node_ids[platdata->periph].name;
	id	= rda_pinctrl_fdt_node_ids[platdata->periph].id;
	blob	= platdata->blob;
	node	= platdata->pinctrl_offset;

	ptr_data = &(platdata->gpio[platdata->node_index]);
	ptr_data->pin_nr = 0;

	offset = fdt_subnode_offset(blob,node,name);
	if(offset < 0)
		return -EFAULT;

	err = fdtdec_get_int_array(blob,offset,"nr",&nr,1);
	if(err) {
		printf("%s, get %s nr failed, %d\n",__func__,name,err);
		return err;
	}
	if(nr > 0) {
		ptr_data->pin_nr = (nr > RDA_PIN_MAX_NR) ? RDA_PIN_MAX_NR : nr;
		if(id != RDA_PINCTRL_ID_GPOA) {
			/* get GPOIO A,B,C,D direct property */
			fdtdec_get_int_array(blob,offset,"direct",buf,ptr_data->pin_nr);
			for(i = 0;i < ptr_data->pin_nr;i++)
				ptr_data->pin_direct[i] = buf[i];
		} else {
			/* get GPOA value property */
			fdtdec_get_int_array(blob,offset,"value",buf,ptr_data->pin_nr);
			for(i = 0;i < ptr_data->pin_nr;i++)
				ptr_data->pin_value[i] = buf[i];
		}
	}
#ifdef RDA_PINCTRL_DEBUG
	for(i = 0;i < ptr_data->pin_nr;i++)
		printf("%s, %s,nr = %d direct = %d,value = %d\n",
			__func__,
			ptr_data->name,
			ptr_data->pin_nr,
			ptr_data->pin_direct[i],
			ptr_data->pin_value[i]);
#endif
	return 0;
}

static int pinctrl_set_gpio(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	const char *name = rda_pinctrl_fdt_node_ids[platdata->periph].name;
	int id = rda_pinctrl_fdt_node_ids[platdata->periph].id;
	u32 i = platdata->node_index;

	if(id != RDA_PINCTRL_ID_GPOA) {
		u32 mask = 0,val = 0,j,dir,pos,gpio_dir = 0;
		u32 gpio_clr 		= bank_grp[i].reg_base_gpio + 0x14;
		u32 gpio_oen_set_out 	= bank_grp[i].reg_base_gpio + 0x04;

		/* get GPIO direction */
		gpio_dir = pinctrl_get_gpio_pin_direction(&platdata->gpio[i]);
		/* get Boot Mode pins */
		for(j = 0;j < platdata->bm[i].pin_nr;j++) {
			pos = platdata->bm[i].pin_id[j];
			dir = platdata->bm[i].pin_direct[j];
			mask |= (1 << pos);
			if(dir)
				val |= (1 << pos);
		}
		dir = (gpio_dir & (~mask)) | val;
		writel(dir,gpio_clr);
		writel(dir,gpio_oen_set_out);

		dprintf("%s, gpio_dir = %x, bm_dir = %x\n",
			__func__,gpio_dir,val);
		dprintf("%s, %s, reg %x = %x\n",
			__func__,name,gpio_clr,readl(gpio_clr));
		dprintf("%s, %s, reg %x = %x\n",
			__func__,name,gpio_oen_set_out,readl(gpio_oen_set_out));
	} else {
		u32 gpo_set = bank_grp[i].reg_base_gpio + 0x30;
		u32 gpo_clr = bank_grp[i].reg_base_gpio + 0x34;
		struct rda_pin_gpio *gpio = &platdata->gpio[i];
		struct rda_pin_comm *comm_pin;
		int j;
		u32 mask = 0,bit,pos;

		/* GPOA pins */
		for(j = 0;j < gpio->pin_nr;j++) {
			bit = gpio->pin_value[j];
			mask = 1 << j;
			if(bit)
				writel(mask,gpo_set);
			else
				writel(mask,gpo_clr);
		}
		/* clk32k pins */
		comm_pin = platdata->clk32k;
		if(comm_pin->pin.enabled) {
			mask = 1 << (comm_pin->pin.pin);
			if(comm_pin->pin.value)
				writel(mask,gpio_set);//set High
			else
				writel(mask,gpo_clr);//set Low
		}
		/* usbid pins */
		comm_pin = platdata->usbid;
		if(comm_pin->pin_enabled) {
			mask = 1 << comm_pin->pin.pin;
			if(comm_pin->pin.value)
				writel(mask,gpo_set);
			else
				writel(mask,gpo_clr);
		}
		dprintf("%s, %s, reg %x = %x\n",__func__,name,gpo_set,readl(gpo_set));
		dprintf("%s, %s, reg %x = %x\n",__func__,name,gpo_clr,readl(gpo_clr));
	}
	return 0;
}

static int pinctrl_gpio_config(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	const char *name = rda_pinctrl_fdt_node_ids[platdata->periph].name;
	int id = rda_pinctrl_fdt_node_ids[platdata->periph].id;
	int r = 0;

	dprintf("%s, periph id = %d, name = %s\n",__func__,id,name);

	switch(id) {
	case RDA_PINCTRL_ID_GPIOA:
		platdata->node_index = 0;// for GPIOA
		break;
	case RDA_PINCTRL_ID_GPIOB:
		platdata->node_index = 1;// for GPIOB
		break;
	case RDA_PINCTRL_ID_GPIOC:
		platdata->node_index = 2;// for GPIOC
		break;
	case RDA_PINCTRL_ID_GPIOD:
		platdata->node_index = 3;// for GPIOD
		break;
	case RDA_PINCTRL_ID_GPOA:
		platdata->node_index = 4;// for GPOA
		break;
	default:
		return -ENODATA;
	}
	r = pinctrl_get_gpio(bank_grp,platdata);
	if(r) {
		dprintf("%s, get gpio %s pin eailed, %d\n",__func__,name,r);
		return r;
	}
	r = pinctrl_set_gpio(bank_grp,platdata);
	if(r) {
		dprintf("%s, set gpio %s pin failed, %d\n",__func__,name,r);
		return r;
	}
	return 0;
}

static int pinctrl_get_clk32k(struct rda_pin_bank *bank_grp,
				struct rda_pinctrl_platdata *platdata)
{
	void *blob;
	int node,offset,err;
	u32 buf[32],nr,i;
	struct rda_pin_comm *ptr_clk;

	blob	= platdata->blob;
	node	= platdata->pinctrl_offset;
	ptr_clk = platdata->clk32k;

	offset = fdt_subnode_offset(blob,node,ptr_clk->name);
	if(offset < 0)
		return -EFAULT;

	err = fdtdec_get_int_array(blob,offset,ptr_clk->pin.name,
					buf,ptr_clk->pin.unit);
	if(err) {
		printf("%s, get %s propery failed, %d\n",__func__,ptr_clk->name,err);
		return err;
	}
	ptr_clk->pin.bank  = buf[0];
	ptr_clk->pin.pin   = buf[1];
	ptr_clk->pin.value = buf[2];
	ptr_clk->pin.enabled = buf[3];

#ifdef RDA_PINCTRL_DEBUG
	for(i = 0;i < ptr_clk->nr;i++)
		printf("%s, %s, %s, bank = %d, pin = %d ,value = %d, enabled = %d\n",
			__func__,
			ptr_clk->name,
			ptr_clk->pin.name,
			ptr_clk->pin.bank,
			ptr_clk->pin.pin,
			ptr_clk->pin.value,
			ptr_clk->pin.enabled);
#endif
	return 0;
}

static int pinctrl_set_clk32k(struct rda_pin_bank *bank_grp,
				struct rda_pinctrl_platdata *platdata)
{
	return 0;
}

static int pinctrl_clk32k_config(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	int r = 0;
	r = pinctrl_get_clk32k(bank_grp,platdata);
	if(r) {
		dprintf("%s, get clk32k pin failed, %d\n",__func__,r);
		return r;
	}
	r = pinctrl_set_clk32k(bank_grp,platdata);
	if(r) {
		dprintf("%s, set clk32k pin failed, %d\n",__func__,r);
		return r;
	}
	return 0;
}

static int pinctrl_get_usbid(struct rda_pin_bank *bank_grp,
				struct rda_pinctrl_platdata *platdata)
{
	void *blob;
	int node,offset,err;
	u32 buf[32],nr,i;
	struct rda_pin_comm *ptr_usbid;

	blob	= platdata->blob;
	node	= platdata->pinctrl_offset;
	ptr_usbid = platdata->usbid;

	offset = fdt_subnode_offset(blob,node,ptr_usbid->name);
	if(offset < 0)
		return -EFAULT;

	err = fdtdec_get_int_array(blob,offset,ptr_usbid->pin.name,buf,ptr_usbid->pin.unit);
	if(err) {
		printf("%s, get %s property failed, %d\n",__func__,ptr_usbid->pin.name,err);
		return err;
	}
	ptr_usbid->pin.bank = buf[0];
	ptr_usbid->pin.pin  = buf[1];
	ptr_usbid->pin.value = buf[2];
	ptr_usbid->pin.enabled = buf[3];

#ifdef RDA_PINCTRL_DEBUG
	for(i = 0;i < ptr_usbid->nr;i++)
		printf("%s, %s, %s, bank = %d, pin = %d ,value = %d, enabled = %d\n",
			__func__,
			ptr_usbid->name,
			ptr_usbid->pin.name,
			ptr_usbid->pin.bank,
			ptr_usbid->pin.pin,
			ptr_usbid->pin.value,
			ptr_usbid->pin.enabled);
#endif
	return 0;
}

static int pinctrl_set_usbid(struct rda_pin_bank *bank_grp,
				struct rda_pinctrl_platdata *platdata)
{
	return 0;
}

static int pinctrl_usbid_config(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	int r = 0;
	r = pinctrl_get_usbid(bank_grp,platdata);
	if(r) {
		dprintf("%s, get usbid pin failed, %d\n",__func__,r);
		return r;
	}
	r = pinctrl_set_usbid(bank_grp,platdata);
	if(r) {
		dprintf("%s, set usbid pin failed, %d\n",__func__,r);
		return r;
	}
	return 0;
}

static int pinctrl_get_uart(struct rda_pin_bank *bank_grp,
				struct rda_pinctrl_platdata *platdata)
{
	int err;
	u32 buf[5];
	void *blob = platdata->blob;
	int node = platdata->pinctrl_offset;
	struct rda_pin_uart *ptr_uart = &(platdata->uart[platdata->node_index]);

	offset = fdt_subnode_offset(blob,node,ptr_uart->name);
	if(offset < 0)
		return -EFAULT;

	err = fdtdec_get_int_array(blob,node,ptr_uart->txd.name,
					buf,ptr_uart->txd.unit);
	if(!err) {
		ptr_uart->txd.bank    = buf[0];
		ptr_uart->txd.pin     = buf[1];
		ptr_uart->txd.value   = buf[2];
		ptr_uart->txd.enabled = buf[3];
	} else {
		ptr_uart->txd.enabled = 0;
	}
	err = fdtdec_get_int_array(blob,node,ptr_uart->rxd.name,
					buf,ptr_uart->rxd.unit);
	if(!err) {
		ptr_uart->rxd.bank    = buf[0];
		ptr_uart->rxd.pin     = buf[1];
		ptr_uart->rxd.value   = buf[2];
		ptr_uart->rxd.enabled = buf[3];
	} else {
		ptr_uart->rxd.enabled = 0;
	}
	err = fdtdec_get_int_array(blob,node,ptr_uart->cts.name,
					buf,ptr_uart->cts.unit);
	if(!err) {
		ptr_uart->cts.bank    = buf[0];
		ptr_uart->cts.pin     = buf[1];
		ptr_uart->cts.value   = buf[2];
		ptr_uart->cts.enabled = buf[3];
	} else {
		ptr_uart->cts.enabled = 0;
	}
	err = fdtdec_get_int_array(blob,node,ptr_uart->rts.name,
					buf,ptr_uart->rts.unit);
	if(!err) {
		ptr_uart->rts.bank    = buf[0];
		ptr_uart->rts.pin     = buf[1];
		ptr_uart->rts.value   = buf[2];
		ptr_uart->rts.enabled = buf[3];
	} else {
		ptr_uart->rts.enabled = 0;
	}
#ifdef RDA_PINCTRL_DEBUG
	printf("%s, %s, %s, bank = %d, pin = %d, value = %d, enabled = %d\n",
		__func__,
		ptr_uart->name,
		ptr_uart->txd.name,
		ptr_uart->txd.bank,
		ptr_uart->txd.pin,
		ptr_uart->txd.value,
		ptr_uart->txd.enabled);
	printf("%s, %s, %s, bank = %d, pin = %d, value = %d, enabled = %d\n",
		__func__,
		ptr_uart->name,
		ptr_uart->rxd.name,
		ptr_uart->rxd.bank,
		ptr_uart->rxd.pin,
		ptr_uart->rxd.value,
		ptr_uart->rxd.enabled);
	printf("%s, %s, %s, bank = %d, pin = %d, value = %d, enabled = %d\n",
		__func__,
		ptr_uart->name,
		ptr_uart->cts.name,
		ptr_uart->cts.bank,
		ptr_uart->cts.pin,
		ptr_uart->cts.value,
		ptr_uart->cts.enabled);
	printf("%s, %s, %s, bank = %d, pin = %d, value = %d, enabled = %d\n",
		__func__,
		ptr_uart->name,
		ptr_uart->rts.name,
		ptr_uart->rts.bank,
		ptr_uart->rts.pin,
		ptr_uart->rts.value,
		ptr_uart->rts.enabled);
#endif
	return 0;
}

static int pinctrl_set_uart(struct rda_pin_bank *bank_grp,
				struct rda_pinctrl_platdata *platdata)
{
	struct rda_pin_uart *ptr_uart = &platdata->uart[platdata->node_index];
	struct rda_pin_bank *ptr_bank;
	struct rda_pin_keyin *ptr_keyin;
	struct rda_pin_keyout *ptr_keyout;
	u32 mask;

	if(ptr_uart->cts.enabled) {
		//TODO: check bank id range

		// to check KEYIN 7 & UART1 CTS
		if(platdata->node_index == 0) {
			if((ptr_uart->cts.pin == ptr_keyin->in[7].pin)
				&&(ptr_keyin->in[7].enabled)) {
				printf("%s, KEYIN 7 is conflict with UART1 CTS\n",__func__);
				return -EFAULT;
			}
		}
		// to check KEYIN 6 & UART2 CTS
		if(platdata->node_index == 1) {
			if((ptr_uart->cts.pin == ptr_keyin->in[6].pin)
				&& (ptr_keyin->in[6].enabled)) {
				printf("%s, KEYIN 6 is conflict with UART2 CTS\n",__func__);
				return -EFAULT;
			}
		}
		ptr_bank = bank_grp[ptr_uart->cts.bank];
		mask = 1 << (ptr_uart->cts.pin);
		ptr_bank->mode &= ~(mask);//set to ALT
	}
	if(ptr_uart->rts.enabled) {
		//TODO: check bank id range

		// to check KEYOUT 7 & UART1 RTS
		if(platdata->node_index == 0) {
			if((ptr_uart->rts.pin == ptr_keyout->out[7].pin)
				&& (ptr_keyout->out[7].enabled)) {
				printf("%s, KEYOUT 7 is conflict with UART1 RTS\n",__func__);
				return -EFAULT;
			}
		}
		// to check KEYOUT 6 & UART2 RTS
		if(platdata->node_index == 1) {
			if((ptr_uart->rts.pin == ptr_keyout->out[6].pin)
				&& (ptr_keyout->out[6].enabled)) {
				printf("%s, KEYOUT 6 is conflict with UART2 RTS\n",__func__);
				return -EFAULT;
			}
		}
		ptr_bank = bank_grp[ptr_uart->rts.bank];
		mask = 1 << (ptr_uart->rts.pin);
		ptr_bank->mode &= ~(mask);//set to ALT
	}
	if(ptr_uart->txd.enabled) {
		//TODO: check bank id range
		ptr_bank = bank_grp[ptr_uart->txd.bank];
		mask = 1 << (ptr_uart->txd.pin);
		ptr_bank->mode &= ~(mask);//set to ALT

		if(platdata->node_index == 1) {
			platdata->altmux |= CFG_REGS_KEYOUT_6_UART2_RTS
					| CFG_REGS_UART2_UART2;
		}
	}
	if(ptr_uart->rxd.enabled) {
		//TODO: check bank id range
		ptr_bank = bank_grp[ptr_uart->rxd.bank];
		mask = 1 << (ptr_uart->rxd.pin);
		ptr_bank->mode &= ~(mask);//set to ALT
	}
	switch(platdata->node_index) {
	case 0://UART1
		if(ptr_uart->rts.enabled)
			platdata->altmux |= CFG_REGS_KEYOUT_7_UART1_RTS;
		else
			platdata->altmux |= CFG_REGS_KEYOUT_7_KEYOUT_7;

		break;
	case 1://UART2
		if(ptr_uart->rts.enabled
			|| ptr_uart->cts.enabled
			|| ptr_uart->txd.enabled
			|| ptr_uart->rxd.enabled)
			platdata->altmux |= CFG_REGS_KEYOUT_6_UART2_RTS
					| CFG_REGS_UART2_UART2;
		else
			platdata->altmux |= CFG_REGS_KEYOUT_6_KEYOUT_6
					| CFG_REGS_UART2_HOST_UART;

		break;
	case 2://UART3
		//nothing to do for UART3 on altmux
		break;
	}
#ifdef RDA_PINCTRL_DEBUG
	for(mask = 0;mask < ARRAY_SIZE(rda_bank_group);i++)
		printf("%s, %s, mode = %x\n",__func__,
		rda_bank_group[mask].name,rda_bank_group[mask].mode);
#endif
	return 0;
}

static int pinctrl_uart_config(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	int r;	
	switch(platdata->periph) {
	case RDA_PINCTRL_ID_UART1:
		platdata->node_index = 0; //UART1
		break;
	case RDA_PINCTRL_ID_UART2:
		platdata->node_index = 1;//UART2
		break;
	case RDA_PINCTRL_ID_UART3:
		platdata->node_index = 2;//UART3
		break;
	default:
		return -ENODATA;
	}
	r = pinctrl_get_uart(bank_grp,platdata);
	if(r) {
		dprintf("%s, get uart pin failed, %d\n",__func__,r);
		return r;
	}
	r = pinctrl_set_uart(bank_grp,platdata);
	if(r) {
		dprintf("%s, get uart pin failed, %d\n",__func__,r);
		return r;
	}
	return 0;
}

static int pinctrl_get_keyin(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	int err;
	u32 buf[5],i;
	void *blob = platdata->blob;
	int node = platdata->pinctrl_offset;
	struct rda_pin_keyin *ptr_keyin = platdata->keyin;
	rda_pin_t *ptr_pin;

	offset = fdt_subnode_offset(blob,node,ptr_keyin->name);
	if(offset < 0)
		return -EFAULT;

	for(i = 0;i < ptr_keyin->nr;i++) {
		ptr_pin = &ptr_keyin->in[i];
		err = fdtdec_get_int_array(blob,node,ptr_pin->name,buf,ptr_pin->unit);
		if(err) {
			printf("%s, get %s failed, %d \n",__func__,ptr_pin->name,err);
			return -EFAULT;
		}
		ptr_pin->bank    = buf[0];
		ptr_pin->pin     = buf[1];
		ptr_pin->value   = buf[2];
		ptr_pin->enabled = buf[3];
	}
#ifdef RDA_PINCTRL_DEBUG
	for(i = 0;i < ptr_keyin->nr;i++) {
		ptr_pin = &ptr_keyin->in[i];
		printf("%s, %s, %s, bank = %d, pin = %d, value = %d, enabled = %d\n",
		__func__,
		ptr_keyin->name,
		ptr_pin.name,
		ptr_pin.bank,
		ptr_pin.pin,
		ptr_pin.value,
		ptr_pin.enabled);
	}
	return 0;
}

static int pinctrl_set_keyin(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	struct rda_pin_bank *ptr_bank;
	struct rda_pin_keyin *ptr_keyin = platdata->keyin;
	rda_pin_t *ptr_pin;
	u32 mask,i;

	for(i = 0;i < ptr_keyin->nr;i++) {
		ptr_pin = &ptr_keyin->in[i];
		if(ptr_pin->enabled) {
			ptr_bank = bank_grp[ptr_pin->bank];
			mask = 1 << ptr_pin->pin;
			ptr_bank->mode |= mask;
		}
	}
	return 0;
}

static int pinctrl_keyin_config(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	r = pinctrl_get_keyin(bank_grp,platdata);
	if(r) {
		dprintf("%s, get keyin pin failed, %d\n",__func__,r);
		return r;
	}
	r = pinctrl_set_keyin(bank_grp,platdata);
	if(r) {
		dprintf("%s, get keyin pin failed, %d\n",__func__,r);
		return r;
	}
	return 0;
}

static int pinctrl_get_keyout(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	int err;
	u32 buf[5],i;
	void *blob = platdata->blob;
	int node = platdata->pinctrl_offset;
	struct rda_pin_keyout *ptr_keyout = platdata->keyout;
	rda_pin_t *ptr_pin;

	offset = fdt_subnode_offset(blob,node,ptr_keyout->name);
	if(offset < 0)
		return -EFAULT;

	for(i = 0;i < ptr_keyout->nr;i++) {
		ptr_pin = &ptr_keyout->out[i];
		err = fdtdec_get_int_array(blob,node,ptr_pin->name,buf,ptr_pin->unit);
		if(err) {
			printf("%s, get %s failed, %d \n",__func__,ptr_pin->name,err);
			return -EFAULT;
		}
		ptr_pin->bank    = buf[0];
		ptr_pin->pin     = buf[1];
		ptr_pin->value   = buf[2];
		ptr_pin->enabled = buf[3];
	}
#ifdef RDA_PINCTRL_DEBUG
	for(i = 0;i < ptr_keyout->nr;i++) {
		ptr_pin = &ptr_keyout->out[i];
		printf("%s, %s, %s, bank = %d, pin = %d, value = %d, enabled = %d\n",
		__func__,
		ptr_keyout->name,
		ptr_pin.name,
		ptr_pin.bank,
		ptr_pin.pin,
		ptr_pin.value,
		ptr_pin.enabled);
	}
	return 0;
}

static int pinctrl_set_keyout(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	struct rda_pin_bank *ptr_bank;
	struct rda_pin_keyout *ptr_keyout = platdata->keyout;
	rda_pin_t *ptr_pin;
	u32 mask,i;

	for(i = 0;i < ptr_keyout->nr;i++) {
		ptr_pin = &ptr_keyout->in[i];
		if(ptr_pin->enabled) {
			ptr_bank = bank_grp[ptr_pin->bank];
			mask = 1 << ptr_pin->pin;
			ptr_bank->mode |= mask;
		}
	}
	return 0;
}

static int pinctrl_keyout_config(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	r = pinctrl_get_keyout(bank_grp,platdata);
	if(r) {
		dprintf("%s, get keyout pin failed, %d\n",__func__,r);
		return r;
	}
	r = pinctrl_set_keyout(bank_grp,platdata);
	if(r) {
		dprintf("%s, get keyin pin failed, %d\n",__func__,r);
		return r;
	}
	return 0;
}

static int pinctrl_get_i2c(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	int err;
	u32 buf[5],i;
	void *blob = platdata->blob;
	int node = platdata->pinctrl_offset;
	struct rda_pin_i2c *ptr_i2c = platdata->i2c[platdata->node_index];

	offset = fdt_subnode_offset(blob,node,ptr_i2c->name);
	if(offset < 0)
		return -EFAULT;

	err = fdtdec_get_int_array(blob,node,ptr_i2c->scl.name,buf,ptr_i2c->scl.unit);
	if(err) {
		printf("%s, get %s failed, %d \n",__func__,ptr_i2c->scl.name,err);
		return -EFAULT;
	}
	ptr_i2c->scl.bank    = buf[0];
	ptr_i2c->scl.pin     = buf[1];
	ptr_i2c->scl.value   = buf[2];
	ptr_i2c->scl.enabled = buf[3];

	err = fdtdec_get_int_array(blob,node,ptr_i2c->sda.name,buf,ptr_i2c->sda.unit);
	if(err) {
		printf("%s, get %s failed, %d \n",__func__,ptr_i2c->sda.name,err);
		return -EFAULT;
	}
	ptr_i2c->sda.bank    = buf[0];
	ptr_i2c->sda.pin     = buf[1];
	ptr_i2c->sda.value   = buf[2];
	ptr_i2c->sda.enabled = buf[3];

#ifdef RDA_PINCTRL_DEBUG
	printf("%s, %s, %s, bank = %d, pin = %d, value = %d, enabled = %d\n",
		__func__,
		ptr_i2c->name,
		ptr_i2c->scl.name,
		ptr_i2c->scl.bank,
		ptr_i2c->scl.pin,
		ptr_i2c->scl.value,
		ptr_i2c->scl.enabled);
	printf("%s, %s, %s, bank = %d, pin = %d, value = %d, enabled = %d\n",
		__func__,
		ptr_i2c->name,
		ptr_i2c->sda.name,
		ptr_i2c->sda.bank,
		ptr_i2c->sda.pin,
		ptr_i2c->sda.value,
		ptr_i2c->sda.enabled);
	return 0;
}

static int pinctrl_set_i2c(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	struct rda_pin_i2c *ptr_i2c = platdata->i3c[platdata->node_index];
	struct rda_pin_bank *ptr_bank;
	struct rda_pin_keyout *ptr_keyout = platdata->keyout;

	if(ptr_i2c->scl.enabled) {
		if(platdata->node_index == 2) {
			if((ptr_i2c->scl.pin == ptr_keyout.out[3].pin)
				&& (platdata->keyout.out[3].enabled)) {
				printf("%s, I2C 3 SCL pin conflicts with KEYOUT 3\n",__func__);
				return -EFAULT;
			}
		}
		ptr_bank = bank_grp[ptr_i2c->scl.bank];
		ptr_bank->mode |= (1 << ptr_i2c->scl.pin);//set ALT
	}
	if(ptr_i2c->sda.enabled) {
		if(platdata->node_index == 2) {
			if((ptr_i2c->sda.pin == ptr_keyout.out[4].pin)
				&& (ptr_keyout.out[4].enabled)) {
				printf("%s, I2C 3 SDA pin conflicts with KEYOUT 4\n",__func__);
				return -EFAULT;
			}
		}
		ptr_bank = bank_grp[ptr_i2c->sda.bank];
		ptr_bank->mode |= (1 << ptr_i2c->sda.pin);//set ALT
	}
	switch(platdata->node_index) {
	case 0://I2C1
		// nothing to do for I2C1 on altmux
		break;
	case 1://I2C2
		if(ptr_i2c->scl.enabled || ptr_i2c->sda.enabled)
			platdata->altmux |= CFG_REGS_CAM_I2C2_I2C2;
		else
			platdata->altmux |= CFG_REGS_CAM_I2C2_CAM;

		break;
	case 2://I2C3
		if(ptr_i2c->scl.enabled || ptr_i2c->sda.enabled)
			platdata->altmux |= CFG_REGS_KEYOUT_3_4_I2C3;
		else
			platdata->altmux |= CFG_REGS_KEYOUT_3_4_KEYOUT_3_4;
		break;
	default:
		return -EINVAL;
	}
	return 0;
}

static int pinctrl_i2c_config(struct rda_pin_bank *bank_grp,
					struct rda_pinctrl_platdata *platdata)
{
	const char *name = rda_pinctrl_fdt_node_ids[platdata->periph].name;
	int id = rda_pinctrl_fdt_node_ids[platdata->periph].id;
	int r = 0;

	switch(id) {
	case RDA_PINCTRL_ID_I2C1:
		platdata->node_index = 0;// I2C1
		break;
	case RDA_PINCTRL_ID_I2C2:
		platdata->node_index = 1;// I2C2
		break;
	case RDA_PINCTRL_ID_I2C3:
		platdata->node_index = 2;// I2C3
		break;
	default:
		return -ENODATA;
	}
	r = pinctrl_get_i2c(bank_grp,platdata);
	if(r) {
		dprintf("%s, get i2c pin failed, %d\n",__func__,r);
		return r;
	}
	r = pinctrl_set_i2c(bank_grp,platdata);
	if(r) {
		dprintf("%s, set i2c pin failed, %d\n",__func__,r);
		return r;
	}
	return 0;
}

/*
 * standard pinctrl interface implementation
 *****************************************************************************
 */

static int rda_pinctrl_request(struct udevice *dev, int periph_id, int flags)
{
	struct rda_pinctrl_platdata *platdata = dev->platdata;
	struct rda_pin_bank *bank_grp = dev->priv;
	int r = 0;

	if(!pinctrl_platdata_valid(platdata)) {
		printf("%s, platdata is invalid\n",__func__);
		return 0;
	}
	switch(periph_id) {
	case RDA_PINCTRL_ID_IODRIVE:
		r = pinctrl_iodrive_config(bank_grp,platdata);
		break;
	case RDA_PINCTRL_ID_BOOTMODE:
		r = pinctrl_bm_config(bank_grp,platdata);
		break;
	case RDA_PINCTRL_ID_CLK32K:
		r = pinctrl_clk32k_config(bank_grp,platdata);
		break;
	case RDA_PINCTRL_ID_USBID:
		r = pinctrl_usbid_config(bank_grp,platdata);
		break;
	case RDA_PINCTRL_ID_UART1:
	case RDA_PINCTRL_ID_UART2:
	case RDA_PINCTRL_ID_UART3:
		r = pinctrl_uart_config(bank_grp,platdta);
		break;
	case RDA_PINCTRL_ID_GPIOA:
	case RDA_PINCTRL_ID_GPIOB:
	case RDA_PINCTRL_ID_GPIOC:
	case RDA_PINCTRL_ID_GPIOD:
	case RDA_PINCTRL_ID_GPOA:
		r = pinctrl_gpio_config(bank_grp,platdata);
		break;
	case RDA_PINCTRL_ID_KEYIN:
		r = pinctrl_keyin_config(bank_grp,platdata);
		break;
	case RDA_PINCTRL_ID_KEYOUT:
		r = pinctrl_keyout_config(bank_grp,platdata);
		break;
	case RDA_PINCTRL_ID_I2C1:
	case RDA_PINCTRL_ID_I2C2:
	case RDA_PINCTRL_ID_I2C3:
		r = pinctrl_i2c_config(bank_grp,platdata);
		break;
	default:
		r = -EINVAL;
	}
	dprintf("%s, request done, periph_id = %d, r = %d\n",
		__func__,periph_id,r);
	return r;
}

static int rda_pinctrl_get_periph_id(struct udevice *dev,
					struct udevice *periph)
{
	int i = 0,id = rda_pinctrl_periph_id[periph->seq];
	int num = ARRAY_SIZE(rda_pinctrl_fdt_node_ids);
	struct rda_pinctrl_platdata *platdata = dev->platdata;

	for(i = 0;i < num;i++)
		if(id == rda_pinctrl_fdt_node_ids[i].id)
			break;
	if(i >= num) {
		printf("%s, periph id %d do not exist\n",__func__,id);
		return -ENODATA;
	}
	platdata->periph = i;
	dprintf("%s, %s, id = %d, periph = %d\n",
		__func__,rda_pinctrl_fdt_node_ids[i].name,id,i);
	return id;
}

static int rda_pinctrl_set_state_simple(struct udevice *dev,
					struct udevice *periph)
{
	int periph_id,i,r = -1;

	if((!dev) || (!periph))
		return -EINVAL;

	for(i = 0; i < ARRAY_SIZE(rda_pinctrl_periph_id);i++) {
		periph->seq = i;
		periph_id = rda_pinctrl_get_periph_id(dev,periph);
		if(periph_id < 0) {
			dprintf("%s, get periph id failed, i = %d, periph_id = %d\n",
					__func__,i,periph_id);
			return -EFAULT;
		}
		r = rda_pinctrl_request(dev,periph_id,0);
		if(r) {
			dprintf("%s, request failed, i = %d, periph_id = %d, r = %d\n",
				__func__,i,periph_id,r);
			return -EFAULT;
		}
	}
	return 0;
}

static struct pinctrl_ops rda_pinctrl_ops = {
	.set_state_simple	= rda_pinctrl_set_state_simple,
	.request		= rda_pinctrl_request,
	.get_periph_id		= rda_pinctrl_get_periph_id,
};

static const struct udevice_id rda_pinctrl_ids[] = {
	{.compatible = "rda,rda-pinctrl"},
};

static int rda_pinctrl_scan_fdt_node(struct udevice *dev,const void *blob)
{
	const char *comp = dev->driver->of_match->compatible;
	int offset;
	u32 flags = 0;

	if(blob == NULL)
		return -EINVAL;
	offset = fdt_node_offset_by_compatible(blob,-1,comp);
	if(offset < 0)
		return -EFAULT;
	dev->of_offset = offset;

	fdtdec_get_int_array(blob,offset,"flags",&flags,1);
	dev->flags = (uint32_t)flags;
	return 0;
}

static int rda_pinctrl_bind(struct udevice *dev)
{
	int r;
	struct rda_pinctrl_platdata *platdata = dev->platdata;

	r = rda_pinctrl_scan_fdt_node(dev,gd->fdt_blob);
	if(r) {
		printf("%s, scan fdt node failed, %d\n",__func__,r);
		return r;
	}
	/* get boot mode */
	platdata->boot_mode = rda_hwcfg_get();

	platdata->blob = (void *)(gd->fdt_blob);
	platdata->pinctrl_offset = dev->of_offset;
	platdata->valid = dev->flags;

	dprintf("%s,  name = %s,id = %d, of_offset = %d, "
		"boot_mode = %x,valid = %d\n",
			__func__,
			platdata->name,
			platdata->id,
			platdata->pinctrl_offset,
			platdata->boot_mode,
			platdata->valid);
	return 0;
}

static int rda_pinctrl_probe(struct udevice *dev)
{
	int r;
	struct udevice periph;
	struct pinctrl_ops *ops = (struct pinctrl_ops *)device_get_ops(dev);
	if(!ops) {
		printf("%s, ops is null\n",__func__);
		return -EINVAL;
	}
	r = ops->set_state_simple(dev,&periph);
	return r;
}

struct driver rda_pinctrl_driver = {
	.name		= "pinctrl",
	.id		= UCLASS_PINCTRL,
	.of_match	= rda_pinctrl_ids,
	.ops		= &rda_pinctrl_ops,
	.probe		= rda_pinctrl_probe,
	.bind		= rda_pinctrl_bind,
};

struct udevice rda_pinctrl_dev[] = {
	[0] = {
		.driver 	= &rda_pinctrl_driver,
		.priv		= &rda_bank_group,
		.platdata	= &rda_platdata[0],
		.name 		= "rda8850e_pinctrl",
	},
};

