// See LICENSE for license details.
#include <string.h>
#include <util.h>
#include <serial.h>
#include <irq.h>

#define IRQ_RESULT0_ADDR 0x00011AF0
#define IRQ_RESULT1_ADDR 0x00011AF4
#define IRQ_ID_ADDR	 0x00011AE8
#define IRQ_FLAG_ADDR    0x00011AEC

#define BOARD_INIT_ADDR  0x00011FF4
#define STR_ADDR_EXCP	 0x00011FF8
#define CALLEXIT_ADDR	 0x00011FFC
#define CALLEXIT_PASS	 0x900dc0de

static void save_excp_addr(unsigned int addr)
{
	writel(addr, STR_ADDR_EXCP);
	return;
}

void do_illegal_inst(void)
{
	save_excp_addr(0x84);
	return;
}

void do_lsu(void)
{
	save_excp_addr(0x8c);
	return;
}

void do_ecall(void)
{
	save_excp_addr(0x88);
	return;
}

#ifndef CONFIG_IRQ_TEST
void dispatch_irq(void)
{
	while(1);
}
#else
void dispatch_irq(void)
{
	int irq_id = readl(IRQ_ID_ADDR);
	int err;

	// if irq state is not set, error
	if(irq_get_state(HWP_IRQ,irq_id) == 0) {
		err = readl(IRQ_RESULT0_ADDR);
		if(err == 0x900dc0de)
			err = 1 << irq_id;
		else
			err |= (1 << irq_id);
		writel(err,IRQ_RESULT0_ADDR);
	}
	// clear pending
	irq_clr_pending(HWP_IRQ,irq_id);
	//write flag = id + 1
	writel(irq_id+1,IRQ_FLAG_ADDR);
}

void sdelay(int cnt)
{
	for(;cnt != 0;cnt--);
}

int irq_simple_test(void)
{
	int flag = 0,err = 0;
	int id = 0;
	HWP_IRQ_T *hwp_irq = HWP_IRQ;

	writel(0x900dc0de,IRQ_RESULT0_ADDR);
	writel(0x900dc0de,IRQ_RESULT1_ADDR);

	for(id = 0;id < 32;id++) {
		// clear flag & write id
		writel(0x0,IRQ_FLAG_ADDR);
		writel(id, IRQ_ID_ADDR);
		// wait ...
		while(readl(IRQ_FLAG_ADDR) != 0);
		// enable irq
		irq_enable(hwp_irq,id);
		// pend a irq
		irq_set_pending(hwp_irq,id);
		// wait until irq is done
		while(1) {
			flag = readl(IRQ_FLAG_ADDR);
			if(flag)
				break;
			sdelay(8000);
		}
		// delay some cycles
		sdelay(8000);
		// if irq state is not cleared, error
		if(irq_get_state(hwp_irq,id) != 0) {
			err |= (1 << id);
		}
	}
	writel(0x0,&hwp_irq->enable);
	if(err)
		writel(err,IRQ_RESULT1_ADDR);
	return err;
}

int irq_nesting_test(void)
{
	return 0;
}
#endif

void board_init(int flag)
{
	writel(0x55aa,BOARD_INIT_ADDR);
}

void call_exit(int err)
{
	if(!err)
		err = CALLEXIT_PASS;
	writel(err,CALLEXIT_ADDR);
}

