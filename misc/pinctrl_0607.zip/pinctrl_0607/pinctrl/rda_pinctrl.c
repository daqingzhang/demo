#include <common.h>
#include <dm/device.h>
#include <dm/pinctrl.h>

DECLARE_GLOBAL_DATA_PTR;

#if 0
static int pinctrl_is_simcard_used(u32 simid)
{
	return 0;
}
#endif

#if defined(CONFIG_MACH_RDA8850E)
#include "rda8850e_pinctrl.c"
#else
#error "unknown machine type !"
#endif

static int rda_pinctrl_dev_add(struct udevice *dev)
{
	int r = 0;
	struct driver *drv = (struct driver *)dev->driver;

	if(!drv) {
		printf("%s, driver do not exist\n",__func__);
		return -EINVAL;
	}
	if((r = drv->bind(dev))) {
		printf("%s, bind pinctrl failed, %d\n",__func__,r);
		return r;
	}
	if((r = drv->probe(dev))) {
		printf("%s, probe pinctrl failed, %d\n",__func__,r);
		return r;
	}
	return r;
}

int rda_pinctrl_init(void)
{
	int i,err;
	for(i = 0;i < ARRAY_SIZE(rda_pinctrl_dev);i++) {
		err = rda_pinctrl_dev_add(&rda_pinctrl_dev[i]);
		if(err) {
			printf("%s, add pinctrl dev %d failed, %d\n",
					__func__,i,err);
			return -EFAULT;
		}
	}
	printf("%s, init pinctrl done\n",__func__);
	return 0;
}
