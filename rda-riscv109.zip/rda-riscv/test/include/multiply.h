#ifndef __MULTIPLY_H__
#define __MULTIPLY_H__

int data32_sum(int max);
int hex2asc(unsigned int hex, char *asc);
unsigned int asc2hex(const char *asc);
int multiply( int x, int y );
#endif
