#ifndef __RDA_PINCTRL_H__
#define __RDA_PINCTRL_H__

enum rda_io_drive_type
{
	IO_DRV_SLOW_AND_MOST_STRONG = 0,
	IO_DRV_SLOW_AND_STRONG,
	IO_DRV_SLOW_AND_WEAK,
	IO_DRV_SLOW_AND_MOST_WEAK,
	IO_DRV_FAST_AND_MOST_STRONG,
	IO_DRV_FAST_AND_STRONG,
	IO_DRV_FAST_AND_WEAK,
	IO_DRV_FAST_AND_MOST_WEAK,
};

enum {
	RDA_PINCTRL_ID_UART1 = 0,
	RDA_PINCTRL_ID_UART2,
	RDA_PINCTRL_ID_UART3,
	RDA_PINCTRL_ID_IODRIVE,
	RDA_PINCTRL_ID_BOOTMODE,
	RDA_PINCTRL_ID_GPIOA,
	RDA_PINCTRL_ID_GPIOB,
	RDA_PINCTRL_ID_GPIOC,
	RDA_PINCTRL_ID_GPIOD,
	RDA_PINCTRL_ID_GPOA,
	RDA_PINCTRL_ID_CLK32K,
	RDA_PINCTRL_ID_USBID,
	RDA_PINCTRL_ID_KEYIN,
	RDA_PINCTRL_ID_KEYOUT,
	RDA_PINCTRL_ID_I2C1,
	RDA_PINCTRL_ID_I2C2,
	RDA_PINCTRL_ID_I2C3,
};

struct rda_fdt_node {
	int id;
	const char *name;
};

typedef union
{
	struct {
		u32 ddr		:3;
		u32 psram1	:3;
		u32 psram2	:3;
		u32 nflash	:3;
		u32 lcd1	:3;
		u32 lcd2	:3;
		u32 sdat1	:3;
		u32 sdat2	:3;
		u32 camera	:2;
		u32 sim1	:2;
		u32 sim2	:2;
		u32 sim3	:2;
		u32 gpio	:2;
	};
	struct {
		u32 reg1;
		u32 reg2;
	};

}rda_pin_iodrive_t;

typedef struct
{
	const char *name;
	u8 bank;	// GPIO Bank: 0:GPIO_A, 1:GPIO_B, 2:GPIO_C, 3:GPIO_D, 4:GPO 5:GPIO_E
	u8 pin;		// GPIO ID:[0,31];
	u8 value;	// 0: Low, 1: High
	u8 enabled;	// 0: disabled, 1: enabled
	u8 unit;
}rda_pin_t;

#define RDA_PIN_INIT(_name,_bank,_pin,_value,_enabled)	\
	{				\
		.name    = _name,	\
		.bank    = _bank,	\
		.pin     = _pin,	\
		.value   = _value,	\
		.enabled = _enabled,	\
		.unit    = 4,		\
	}				\

struct rda_pin_uart {
	const char *name;// the node name string
	u32	nr;//the pins number
	rda_pin_t txd;
	rda_pin_t rxd;
	rda_pin_t cts;
	rda_pin_t rts;
};

struct rda_pin_keyin {
	const char *name;
	u32 nr;
	rda_pin_t in[8];
};

struct rda_pin_keyout {
	const char *name;
	u32 nr;
	rda_pin_t out[8];
};

struct rda_pin_comm {
	const char *name;
	u32 nr;
	rda_pin_t pin;
};

#define RDA_PIN_MAX_NR	32

struct rda_pin_gpio
{
	const char *name;
	u8 pin_nr;
	u8 pin_id[RDA_PIN_MAX_NR];
	u8 pin_direct[RDA_PIN_MAX_NR];
	u8 pin_value[RDA_PIN_MAX_NR];
};

#define RDA_PIN_GPIO_INIT(_name,_nr)	\
		{			\
			.name = _name,	\
			.pin_nr = _nr	\
		}			\


struct rda_pinctrl_platdata
{
	u8 id;
	const char *name;
	u32 valid;	// >0 is valid
	u32 node_index;	//sub node index
	int pinctrl_offset;
	void *blob;
	int periph;

	u16 boot_mode;
	u32 altmux;
	struct rda_pin_gpio *gpio;
	struct rda_pin_gpio *bm;
	struct rda_pin_comm *clk32k;
	struct rda_pin_comm *usbid;
	struct rda_pin_uart *uart;
	struct rda_pin_i2c *i2c;
	struct rda_pin_keyin *keyin;
	struct rda_pin_keyout *keyout;
	rda_pin_iodrive_t   *iodrive;
};

enum rda_pin_mode
{
	ALT_MODE = 0,
	GPIO_MODE = 1,
};

struct rda_pin_bank
{
	u8 id;			// bank id
	const char *name; 	// bank name
	u8  nr_pins;		// gpio pin numbers
	u32 reg_base_gpio;	// base address of gpio register
	u32 reg_base_cfg;	// base address of config register
	u32 mode;		// gpio pin mode,0 = ALT, 1 = GPIO
};

#define RDA_PIN_BANK_INIT(_id, _name, _nr_pins, _reg_base1, _reg_base2)	\
	{							\
		.id 	   	= _id,				\
		.name      	= _name,			\
		.nr_pins   	= _nr_pins,			\
		.reg_base_gpio 	= _reg_base1,			\
		.reg_base_cfg  	= _reg_base2,			\
		.mode 		= 0xFFFFFFFF,			\
	}							\


#endif /*  __PINCTRL_RDA_H__ */

