#ifndef __IRQ_H__
#define __IRQ_H__

#define RDA_IRQ_BASE 0x00028000

typedef volatile unsigned int R_REG32;
typedef volatile unsigned int RW_REG32;
typedef volatile unsigned int RW1_REG32;

typedef volatile struct {
	RW_REG32  enable;
	R_REG32   pending;
	RW1_REG32 setpending;
	RW1_REG32 clrpending;
}HWP_IRQ_T;

#define HWP_IRQ	((HWP_IRQ_T *) (RDA_IRQ_BASE))

static inline void irq_enable(HWP_IRQ_T *hwp_irq, int id)
{
	int mask = 1 << id;
	hwp_irq->enable |= mask;
}

static inline void irq_disable(HWP_IRQ_T *hwp_irq, int id)
{
	int mask = 1 << id;
	hwp_irq->enable &= ~mask;
}

static inline void irq_set_pending(HWP_IRQ_T *hwp_irq, int id)
{
	int mask = 1 << id;
	hwp_irq->setpending = mask;
}

static inline void irq_clr_pending(HWP_IRQ_T *hwp_irq, int id)
{
	int mask = 1 << id;
	hwp_irq->clrpending = mask;
}

static inline int irq_get_state(HWP_IRQ_T *hwp_irq, int id)
{
	int mask = 1 << id;
	mask = hwp_irq->pending & mask;
	return mask;
}

#define RV32_ARRAY_SIZE(tab) (sizeof((tab)) / sizeof((tab)[0]))

#define readl(addr) (*(volatile unsigned int *)(addr))
#define writel(val,addr) (*(volatile unsigned int *)(addr) = (val))

void core_irq_enable(void);
void core_irq_disable(void);

void call_exit(int err);

#endif
